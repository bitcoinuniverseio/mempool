import contracts from './lib/session.js';

export const {
  WALLET_SESSION_VERSION,
  WALLET_PERMISSION_SCOPES,
  ADDRESS_ROLES,
  normalizeBitcoinAddress,
  normalizeWalletSession,
  walletSessionFromProviderState,
  createDisconnectedWalletSession,
} = contracts;

export default contracts;

'use strict';

module.exports = require('./lib/metadata.js');

/**
 * Types for the Bitcoin Universe Control Center contract.
 *
 * Kept in its own declaration file so a consumer that only needs the admin
 * vocabulary does not have to pull the whole ecosystem surface into its
 * type graph.
 */

export type AdminApplication = 'inscribe' | 'core' | 'explorer';
export type AdminEnvironment = 'production' | 'staging' | 'test' | 'development';
export type AdminNetwork =
  | 'bitcoin:mainnet'
  | 'bitcoin:testnet'
  | 'bitcoin:signet'
  | 'bitcoin:regtest'
  | 'dogecoin:mainnet'
  | 'dogecoin:testnet'
  | 'zcash:mainnet'
  | 'zcash:testnet';

export type AdminHealthState =
  | 'healthy'
  | 'syncing'
  | 'stale'
  | 'degraded'
  | 'unavailable'
  | 'disabled_by_policy'
  | 'not_configured'
  | 'unknown';

export type AdminRiskLevel = 'SAFE' | 'GUARDED' | 'HIGH_RISK' | 'IRREVERSIBLE';

export type AdminRunState =
  | 'QUEUED'
  | 'PRECHECK'
  | 'RUNNING'
  | 'WAITING'
  | 'VERIFYING'
  | 'SUCCEEDED'
  | 'FAILED'
  | 'CANCEL_REQUESTED'
  | 'CANCELLED'
  | 'NEEDS_REVIEW'
  | 'ROLLING_BACK'
  | 'ROLLED_BACK'
  | 'ROLLBACK_FAILED';

export type AdminResourceKind =
  | 'service'
  | 'dependency'
  | 'protocol'
  | 'indexer'
  | 'order'
  | 'transaction'
  | 'address'
  | 'block'
  | 'inscription'
  | 'asset'
  | 'collection'
  | 'media'
  | 'job'
  | 'run'
  | 'queue'
  | 'worker'
  | 'node'
  | 'database'
  | 'incident'
  | 'alert'
  | 'release'
  | 'workflow'
  | 'runner'
  | 'commit'
  | 'pull-request'
  | 'audit-event'
  | 'operator'
  | 'service-token'
  | 'setting'
  | 'saved-view'
  | 'slo';

export type AdminRole =
  | 'SUPER_ADMIN'
  | 'OPERATOR'
  | 'INCIDENT_RESPONDER'
  | 'RELEASE_MANAGER'
  | 'VIEWER'
  | 'SECURITY_AUDITOR';

export type AdminPermission =
  | 'read'
  | 'operate.safe'
  | 'operate.guarded'
  | 'operate.high_risk'
  | 'operate.irreversible'
  | 'incidents.manage'
  | 'releases.stage'
  | 'releases.promote'
  | 'releases.rollback'
  | 'ci.dispatch'
  | 'settings.write'
  | 'access.manage'
  | 'audit.export'
  | 'observability.read';

export type AdminIncidentState =
  | 'TRIGGERED'
  | 'ACKNOWLEDGED'
  | 'INVESTIGATING'
  | 'MONITORING'
  | 'RESOLVED';

export type AdminSeverity = 'critical' | 'major' | 'minor' | 'info';

export type AdminReleaseState =
  | 'CANDIDATE'
  | 'BUILDING'
  | 'VERIFIED'
  | 'STAGED'
  | 'CANARY'
  | 'PROMOTION_BLOCKED'
  | 'PROMOTING'
  | 'LIVE'
  | 'DEGRADED'
  | 'ROLLING_BACK'
  | 'ROLLED_BACK'
  | 'SUPERSEDED';

export type AdminSourceOutcome =
  | 'answered'
  | 'stale'
  | 'timeout'
  | 'unauthorized'
  | 'unsupported'
  | 'error'
  | 'circuit_open';

export type AdminScalar = string | number | boolean | null | string[];
export type AdminScalarMap = Record<string, AdminScalar>;

export interface AdminEnvelope {
  schemaVersion: 'admin-control-v1';
  contractVersion: string;
  application: AdminApplication;
  environment: AdminEnvironment;
  generatedAt: string;
}

export interface AdminReleaseIdentity {
  sha: string | null;
  version: string | null;
  builtAt: string | null;
  frontendSha: string | null;
  backendSha: string | null;
  workerSha: string | null;
  adapterSha: string | null;
  migrationVersion: string | null;
  configSchemaVersion: string | null;
  repository: string | null;
  branch: string | null;
}

export interface AdminComponentReport {
  id: string;
  kind: AdminResourceKind;
  name: string;
  state: AdminHealthState;
  reason: string | null;
  network: AdminNetwork | null;
  lastSuccessAt: string | null;
  lastCheckedAt: string | null;
  probeLatencyMs: number | null;
  chainTip: number | null;
  indexedTip: number | null;
  lagBlocks: number | null;
  lagSeconds: number | null;
  maxLagBlocks: number | null;
  queueDepth: number | null;
  oldestQueueAgeSeconds: number | null;
  sourceReleaseSha: string | null;
  runbook: string | null;
  dependsOn: string[];
  operations: string[];
  metrics: AdminScalarMap;
}

export interface AdminAttentionItem {
  id: string;
  severity: AdminSeverity;
  title: string;
  detail: string;
  resourceKind: AdminResourceKind | null;
  resourceId: string | null;
  suggestedOperationId: string | null;
  since: string | null;
  userImpact: string | null;
}

export interface AdminManifest extends AdminEnvelope {
  supportedContractVersions: string[];
  networks: AdminNetwork[];
  release: AdminReleaseIdentity;
  capabilities: Array<{
    id: string;
    label: string;
    supported: boolean;
    reason: string | null;
  }>;
  resourceKinds: AdminResourceKind[];
  operationCount: number;
  adapterName: string;
}

export interface AdminSnapshot extends AdminEnvelope {
  network: AdminNetwork | null;
  release: AdminReleaseIdentity;
  health: { state: AdminHealthState; summary: string; reason: string | null };
  components: AdminComponentReport[];
  dependencies: AdminComponentReport[];
  indexers: AdminComponentReport[];
  queues: AdminComponentReport[];
  workers: AdminComponentReport[];
  counters: AdminScalarMap;
  attention: AdminAttentionItem[];
}

export interface AdminResourceRelation {
  kind: AdminResourceKind;
  id: string;
  label: string;
  relation: string;
}

export interface AdminTimelineEntry {
  at: string;
  source: string;
  title: string;
  detail: string | null;
  correlationId: string | null;
}

export interface AdminResource {
  kind: AdminResourceKind;
  id: string;
  application: AdminApplication;
  environment: AdminEnvironment;
  network: AdminNetwork | null;
  name: string;
  state: AdminHealthState;
  statusLabel: string | null;
  summary: string | null;
  createdAt: string | null;
  updatedAt: string | null;
  sourceReleaseSha: string | null;
  attributes: AdminScalarMap;
  operations: string[];
  related: AdminResourceRelation[];
  timeline: AdminTimelineEntry[];
}

export interface AdminPageInfo {
  limit: number;
  total: number | null;
  nextCursor: string | null;
  truncated: boolean;
}

export interface AdminResourcePage extends AdminEnvelope {
  kind: AdminResourceKind | null;
  items: AdminResource[];
  page: AdminPageInfo;
}

export interface AdminResourceEnvelope extends AdminEnvelope {
  resource: AdminResource;
}

export interface AdminOperationInputField {
  name: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'boolean' | 'textarea';
  required: boolean;
  options: string[];
  help: string | null;
  sensitive: boolean;
  pattern: string | null;
}

export interface AdminOperationDefinition {
  id: string;
  version: string;
  application: AdminApplication;
  resourceKind: AdminResourceKind | null;
  action: string;
  name: string;
  description: string;
  risk: AdminRiskLevel;
  requiredPermission: string;
  environments: AdminEnvironment[];
  networks: AdminNetwork[];
  availability: 'enabled' | 'disabled_by_policy' | 'not_configured' | 'unavailable';
  availabilityReason: string | null;
  inputFields: AdminOperationInputField[];
  preview: boolean;
  idempotent: boolean;
  cancellable: boolean;
  rollbackSupported: boolean;
  retryPolicy: 'none' | 'manual' | 'bounded-automatic';
  timeoutSeconds: number | null;
  concurrency: 'exclusive-per-target' | 'exclusive-global' | 'parallel';
  lock: string | null;
  sideEffects: string[];
  postconditions: string[];
  redactedFields: string[];
  userImpact: string | null;
  publicServiceImpact: string | null;
  runbook: string | null;
}

export interface AdminOperationCatalog extends AdminEnvelope {
  items: AdminOperationDefinition[];
}

export interface AdminOperationPreview extends AdminEnvelope {
  operationId: string;
  operationVersion: string;
  risk: AdminRiskLevel;
  available: boolean;
  unavailableReason: string | null;
  previewToken: string | null;
  expiresAt: string | null;
  target: string;
  preconditions: Array<{
    id: string;
    label: string;
    satisfied: boolean;
    detail: string | null;
  }>;
  effects: string[];
  expectedPostconditions: string[];
  warnings: string[];
  impact: {
    users: string | null;
    publicServices: string | null;
    estimatedDurationSeconds: number | null;
    estimatedStorageBytes: number | null;
    reversible: boolean;
  };
  redactedInput: AdminScalarMap;
}

export interface AdminRunStep {
  id: string;
  name: string;
  state: AdminRunState;
  startedAt: string | null;
  finishedAt: string | null;
  detail: string | null;
}

export interface AdminRun {
  runId: string;
  operationId: string;
  operationVersion: string;
  state: AdminRunState;
  target: string;
  correlationId: string;
  idempotencyKey: string | null;
  actor: string;
  reason: string | null;
  queuedAt: string;
  startedAt: string | null;
  updatedAt: string;
  finishedAt: string | null;
  heartbeatAt: string | null;
  progressPercent: number | null;
  cancellable: boolean;
  replayed: boolean;
  steps: AdminRunStep[];
  logs: Array<{ at: string; level: 'debug' | 'info' | 'warn' | 'error'; message: string }>;
  result: AdminScalarMap;
  verification: { verified: boolean; evidence: string[] };
  error: { class: string; message: string; retryable: boolean } | null;
  rollback: { supported: boolean; state: AdminRunState | null };
}

export interface AdminRunEnvelope extends AdminEnvelope {
  run: AdminRun;
}

export interface AdminAuditEntry {
  id: string;
  at: string;
  application: AdminApplication;
  actor: string;
  action: string;
  target: string | null;
  outcome: 'succeeded' | 'failed' | 'denied' | 'started' | 'cancelled' | 'needs_review';
  risk: AdminRiskLevel | null;
  correlationId: string | null;
  reason: string | null;
  detail: AdminScalarMap;
}

export interface AdminAuditPage extends AdminEnvelope {
  items: AdminAuditEntry[];
  page: AdminPageInfo;
}

export interface AdminEvent {
  id: string;
  at: string;
  application: AdminApplication;
  kind: string;
  severity: AdminSeverity;
  message: string;
  resourceKind: AdminResourceKind | null;
  resourceId: string | null;
  correlationId: string | null;
  data: AdminScalarMap;
}

export interface AdminSearchResults extends AdminEnvelope {
  query: string;
  items: AdminResource[];
  truncated: boolean;
}

export declare const ADMIN_CONTROL_CONTRACT_VERSION: string;
export declare const ADMIN_CONTROL_SCHEMA_VERSION: 'admin-control-v1';
export declare const ADMIN_CONTROL_SUPPORTED_VERSIONS: readonly string[];
export declare const ADMIN_APPLICATIONS: readonly AdminApplication[];
export declare const ADMIN_ENVIRONMENTS: readonly AdminEnvironment[];
export declare const ADMIN_NETWORKS: readonly AdminNetwork[];
export declare const ADMIN_HEALTH_STATES: readonly AdminHealthState[];
export declare const ADMIN_HEALTH_RANK: Readonly<Record<AdminHealthState, number>>;
export declare const ADMIN_RISK_LEVELS: readonly AdminRiskLevel[];
export declare const ADMIN_ELEVATED_RISK_LEVELS: readonly AdminRiskLevel[];
export declare const ADMIN_RUN_STATES: readonly AdminRunState[];
export declare const ADMIN_TERMINAL_RUN_STATES: readonly AdminRunState[];
export declare const ADMIN_RUN_TRANSITIONS: Readonly<Record<AdminRunState, readonly AdminRunState[]>>;
export declare const ADMIN_RESOURCE_KINDS: readonly AdminResourceKind[];
export declare const ADMIN_ROLES: readonly AdminRole[];
export declare const ADMIN_PERMISSIONS: readonly AdminPermission[];
export declare const ADMIN_ROLE_PERMISSIONS: Readonly<Record<AdminRole, readonly AdminPermission[]>>;
export declare const ADMIN_RISK_PERMISSION: Readonly<Record<AdminRiskLevel, AdminPermission>>;
export declare const ADMIN_INCIDENT_STATES: readonly AdminIncidentState[];
export declare const ADMIN_SEVERITIES: readonly AdminSeverity[];
export declare const ADMIN_RELEASE_STATES: readonly AdminReleaseState[];
export declare const ADMIN_SOURCE_OUTCOMES: readonly AdminSourceOutcome[];
export declare const ADMIN_ADAPTER_ROUTES: Readonly<
  Record<string, { method: string; path: string }>
>;
export declare const ADMIN_IDENTIFIER: RegExp;

export declare const ADMIN_SERVICE_SIGNATURE_ALGORITHM: string;
export declare const ADMIN_SERVICE_SIGNATURE_VERSION: string;
export declare const ADMIN_SERVICE_MAX_CLOCK_SKEW_SECONDS: number;
export declare const ADMIN_SERVICE_NONCE_TTL_SECONDS: number;
export declare const ADMIN_SERVICE_HEADERS: Readonly<{
  keyId: string;
  timestamp: string;
  nonce: string;
  bodyDigest: string;
  signature: string;
  correlationId: string;
  contractVersion: string;
}>;
export declare const ADMIN_REDACTED_FIELD_PATTERNS: readonly string[];
export declare const ADMIN_REDACTION_PLACEHOLDER: string;
export declare const ADMIN_REDACTION_MAX_DEPTH: number;

export declare function worseAdminHealthState(
  left: AdminHealthState,
  right: AdminHealthState,
): AdminHealthState;
export declare function foldAdminHealthStates(states: AdminHealthState[]): AdminHealthState;
export declare function isAdminContractVersionSupported(version: string): boolean;
export declare function isAdminRunTerminal(state: AdminRunState): boolean;
export declare function isAdminRunTransitionAllowed(
  from: AdminRunState,
  to: AdminRunState,
): boolean;
export declare function adminRoleGrants(role: AdminRole, permission: AdminPermission): boolean;
export declare function adminPermissionForRisk(risk: AdminRiskLevel): AdminPermission | null;
export declare function adminRiskRequiresElevation(risk: AdminRiskLevel): boolean;

export declare function parseAdminManifest(value: unknown): AdminManifest;
export declare function parseAdminSnapshot(value: unknown): AdminSnapshot;
export declare function parseAdminResourcePage(value: unknown): AdminResourcePage;
export declare function parseAdminResource(value: unknown): AdminResourceEnvelope;
export declare function parseAdminOperationCatalog(value: unknown): AdminOperationCatalog;
export declare function parseAdminOperationPreview(value: unknown): AdminOperationPreview;
export declare function parseAdminOperationRun(value: unknown): AdminRunEnvelope;
export declare function parseAdminAuditPage(value: unknown): AdminAuditPage;
export declare function parseAdminEvent(value: unknown): AdminEvent;
export declare function parseAdminSearchResults(value: unknown): AdminSearchResults;
export declare function createAdminEnvelope(input: {
  application: AdminApplication;
  environment: AdminEnvironment;
  generatedAt: string;
}): AdminEnvelope;

export declare function isRedactedFieldName(name: string): boolean;
export declare function redactAdminPayload<T>(value: T, depth?: number): unknown;
export declare function adminServiceSigningString(input: {
  method: string;
  path: string;
  query?: string | URLSearchParams | Record<string, unknown> | null;
  keyId: string;
  timestamp: string;
  nonce: string;
  bodyDigest: string;
}): string;
export declare function normalizeAdminQuery(
  query: string | URLSearchParams | Record<string, unknown> | null | undefined,
): string;
export declare function isAdminServiceTimestampFresh(
  timestamp: string | number,
  nowMs?: number,
): boolean;

declare const adminControl: {
  ADMIN_CONTROL_CONTRACT_VERSION: typeof ADMIN_CONTROL_CONTRACT_VERSION;
  ADMIN_CONTROL_SCHEMA_VERSION: typeof ADMIN_CONTROL_SCHEMA_VERSION;
  [key: string]: unknown;
};
export default adminControl;

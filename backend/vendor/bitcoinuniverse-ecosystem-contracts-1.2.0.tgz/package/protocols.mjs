import contracts from './lib/protocols.js';

export const {
  PROTOCOL_CAPABILITIES,
  PROTOCOL_ALIASES,
  MARKETPLACE_CAPABILITY_ACTIONS,
  MARKETPLACE_PROTOCOL_REGISTRY,
  normalizeProtocolId,
  getProtocolCapability,
  getProtocolActions,
  isProtocolActionSupported,
  getProtocolMarketplacePolicy,
  getProtocolMarketplaceActionCapability,
  explainUnsupportedProtocolAction,
} = contracts;

export default contracts;

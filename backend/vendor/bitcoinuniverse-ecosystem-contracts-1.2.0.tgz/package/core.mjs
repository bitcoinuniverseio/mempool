import contracts from './lib/core.js';

export const {
  CONTRACT_VERSION,
  SCHEMA_VERSION,
  ECOSYSTEM_APP_IDS,
  BITCOIN_NETWORKS,
  APPLICATION_RESPONSIBILITIES,
  APP_DEFINITIONS,
  DEFAULT_APP_ORIGINS,
  FORBIDDEN_FIELD_PATTERN,
  ContractValidationError,
  fail,
  isPlainObject,
  assertPlainObject,
  assertOnlyKeys,
  normalizeString,
  normalizeOptionalString,
  normalizeEnum,
  normalizeInteger,
  normalizeNumber,
  normalizeIsoDate,
  normalizeAppId,
  normalizeNetwork,
  looksSensitive,
  looksLikeWalletAddress,
  safeUrlOrigin,
  resolveAppIdForOrigin,
  resolveAppUrl,
  deepFreeze,
  frozenCopy,
} = contracts;

export default contracts;

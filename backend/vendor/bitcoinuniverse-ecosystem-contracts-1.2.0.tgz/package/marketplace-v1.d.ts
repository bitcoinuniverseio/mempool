export const MARKETPLACE_V1_CONTRACT_VERSION: '1';
export const MARKETPLACE_V1_MAX_UINT64: '18446744073709551615';
export const MARKETPLACE_V1_MAX_ATOMIC_VALUE: '99999999999999999999999999999999999999999999999999999999999999999';
export const MARKETPLACE_V1_SUPPORTED_NETWORKS: readonly [
  'bitcoin:mainnet',
  'bitcoin:testnet',
  'bitcoin:signet',
  'bitcoin:regtest',
  'dogecoin:mainnet',
  'dogecoin:testnet',
  'fractal:mainnet',
  'fractal:testnet',
];
export type MarketplaceV1Network =
  (typeof MARKETPLACE_V1_SUPPORTED_NETWORKS)[number];

export const MARKETPLACE_V1_SORT_FIELDS: readonly [
  'createdAt',
  'updatedAt',
  'priceAtomic',
  'quantityAtomic',
  'expiresAt',
];

export const MARKETPLACE_V1_PROTOCOL_IDS: readonly [
  'ordinals',
  'tap',
  'dmt',
  'unat',
  'bitmap',
  'names',
  'dust20',
  'stamps',
  'src20',
  'brc20',
  'runes',
  'runes_native',
  'mezcal',
  'alkanes',
  'op_return',
  'op_names',
  'op_inscriptions',
  'op_drop',
  'drops',
  'tap_doge',
  'drc20',
  'doginals',
  'arc20',
  'atomicals_nft',
  'realms',
  'subrealms',
  'rare_sats',
  'cat20',
  'ordex',
];
export type MarketplaceV1ProtocolId =
  (typeof MARKETPLACE_V1_PROTOCOL_IDS)[number];

export const MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS: readonly [
  'list',
  'update-listing',
  'unlist',
  'buy',
  'make-offer',
  'accept-offer',
];
export type MarketplaceV1WalletExecutorAction =
  (typeof MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS)[number];
export const MARKETPLACE_V1_ATOMICALS_WALLET_PROTOCOL_IDS: readonly [
  'arc20',
  'atomicals_nft',
  'realms',
  'subrealms',
];
export interface MarketplaceV1WalletExecutorBinding {
  readonly walletExecutorId:
    | 'core-bitcoin-wallet-v1'
    | 'core-dogecoin-wallet-v1';
  readonly network: 'bitcoin:mainnet' | 'dogecoin:mainnet';
  readonly actions: readonly MarketplaceV1WalletExecutorAction[];
}
export const MARKETPLACE_V1_DEFAULT_WALLET_EXECUTOR_BINDINGS: Readonly<
  Partial<Record<MarketplaceV1ProtocolId, MarketplaceV1WalletExecutorBinding>>
>;

export type MarketplaceV1ExecutionKind =
  | 'core-wallet'
  | 'external-wallet'
  | 'external-marketplace'
  | 'external-psbt'
  | 'nostr-signature'
  | 'server-authorized'
  | 'read-only';
export type MarketplaceV1SignerKind =
  | 'bitcoin-wallet'
  | 'dogecoin-wallet'
  | 'external-wallet'
  | 'nostr-or-wallet-psbt'
  | 'server-identity'
  | 'none';
export type MarketplaceV1ExecutionAction =
  | 'view'
  | 'view-collection'
  | 'view-activity'
  | 'list'
  | 'update-listing'
  | 'unlist'
  | 'buy'
  | 'make-offer'
  | 'accept-offer'
  | 'cancel-offer'
  | 'sell'
  | 'settle'
  | 'reconcile';
export type MarketplaceV1AuthorityPort =
  | 'browse'
  | 'listing'
  | 'update'
  | 'delist'
  | 'purchase'
  | 'offers'
  | 'settlement';
export const MARKETPLACE_V1_AUTHORITY_PORT_BY_ACTION: Readonly<
  Record<MarketplaceV1ExecutionAction, MarketplaceV1AuthorityPort>
>;
export const MARKETPLACE_V1_PROTOCOL_NETWORKS: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1Network>
>;
export interface MarketplaceV1ExecutionContract {
  readonly protocolId: MarketplaceV1ProtocolId;
  readonly action: MarketplaceV1ExecutionAction;
  readonly advertised: boolean;
  readonly supportsMutation: boolean;
  readonly executionKind: MarketplaceV1ExecutionKind;
  readonly signerKind: MarketplaceV1SignerKind;
  readonly authorityOwner: string;
  readonly builderOwner: string;
  readonly validatorOwner: string;
  readonly broadcastOwner: string;
  readonly settlementOwner: string;
  readonly escrowModel: string;
  readonly custodyModel: string;
  readonly ownershipModel: string;
  readonly transferabilityProof: string;
  readonly network: MarketplaceV1Network;
  readonly requiredAuthority: string;
  readonly requiredDeploymentIdentity: string;
  readonly requiredEvidenceKind: string;
  readonly requiresBroadcast: boolean;
  readonly requiresSettlement: boolean;
  readonly walletExecutorId: string | null;
}
export const MARKETPLACE_V1_EXECUTION_KINDS: readonly MarketplaceV1ExecutionKind[];
export const MARKETPLACE_V1_SIGNER_KINDS: readonly MarketplaceV1SignerKind[];
export const MARKETPLACE_V1_EXECUTION_CONTRACTS: readonly MarketplaceV1ExecutionContract[];
export const MARKETPLACE_V1_EXECUTION_CONTRACT_BY_SCOPE: Readonly<
  Record<string, MarketplaceV1ExecutionContract>
>;
export interface MarketplaceV1AuthorityMatrixRow {
  readonly protocolId: MarketplaceV1ProtocolId;
  readonly network: MarketplaceV1Network;
  readonly availability: string;
  readonly featureGate: string | null;
  readonly staticCapabilities: Readonly<Record<string, unknown>>;
  readonly advertisedActions: readonly MarketplaceV1ExecutionAction[];
  readonly mutationActions: readonly MarketplaceV1ExecutionAction[];
  readonly requiredPorts: readonly MarketplaceV1AuthorityPort[];
  readonly executionKinds: readonly MarketplaceV1ExecutionKind[];
  readonly signerKinds: readonly MarketplaceV1SignerKind[];
  readonly requiredAuthorities: readonly string[];
  readonly requiredDeploymentIdentities: readonly string[];
  readonly requiredEvidenceKinds: readonly string[];
  readonly owners: Readonly<{
    authority: readonly string[];
    builder: readonly string[];
    validator: readonly string[];
    broadcast: readonly string[];
    settlement: readonly string[];
  }>;
  readonly walletExecutorBinding: MarketplaceV1WalletExecutorBinding | null;
}
export const MARKETPLACE_V1_AUTHORITY_MATRIX: readonly MarketplaceV1AuthorityMatrixRow[];
export const MARKETPLACE_V1_AUTHORITY_MATRIX_BY_PROTOCOL: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1AuthorityMatrixRow>
>;
export type MarketplaceV1ExecutionOwnership =
  | 'remote-authority'
  | 'core-native'
  | 'external-provider'
  | 'none';
export const MARKETPLACE_V1_EXECUTION_OWNERSHIP_KINDS: readonly MarketplaceV1ExecutionOwnership[];
export const MARKETPLACE_V1_EXECUTION_OWNERSHIP_BY_PROTOCOL: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1ExecutionOwnership>
>;
export function getMarketplaceV1ExecutionOwnership(
  protocolId: unknown,
): MarketplaceV1ExecutionOwnership;
export function getMarketplaceV1ExecutionContract(
  protocolId: unknown,
  action: unknown,
): MarketplaceV1ExecutionContract;
export function listMarketplaceV1ExecutionContracts(options?: {
  advertisedOnly?: boolean;
  mutationOnly?: boolean;
}): MarketplaceV1ExecutionContract[];

export type MarketplaceV1LifecycleState =
  | 'draft'
  | 'prepared'
  | 'signed'
  | 'open'
  | 'reserved'
  | 'settling'
  | 'broadcast'
  | 'confirmed'
  | 'indexing'
  | 'indexed'
  | 'settled'
  | 'cancelling'
  | 'cancelled'
  | 'expired'
  | 'failed-retryable'
  | 'failed-final'
  | 'dropped'
  | 'replaced'
  | 'conflicted'
  | 'reorged'
  | 'recovering';

export const MARKETPLACE_V1_LIFECYCLE_STATES: readonly MarketplaceV1LifecycleState[];
export const MARKETPLACE_V1_LIFECYCLE_TRANSITIONS: Readonly<
  Record<MarketplaceV1LifecycleState, readonly MarketplaceV1LifecycleState[]>
>;

export function normalizeMarketplaceV1ProtocolId(
  value: unknown,
  path?: string,
): MarketplaceV1ProtocolId;
export function normalizeMarketplaceV1LifecycleState(
  value: unknown,
  path?: string,
): MarketplaceV1LifecycleState;
export function normalizeMarketplaceV1Revision(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1AtomicValue(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1Network(
  value: unknown,
  path?: string,
): MarketplaceV1Network;
export function normalizeMarketplaceV1OpaqueId(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1Timestamp(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1IdempotencyKey(
  value: unknown,
  path?: string,
): string;

export interface MarketplaceV1WalletAuth {
  readonly address: string;
  readonly nonce: string;
  readonly signature: string;
  readonly signatureType: 'bip322-simple' | 'dogecoin-signmessage';
}

export function normalizeMarketplaceV1WalletAuth(
  value: unknown,
  path?: string,
): Readonly<MarketplaceV1WalletAuth>;
export function canTransitionMarketplaceV1Lifecycle(
  from: MarketplaceV1LifecycleState | string,
  to: MarketplaceV1LifecycleState | string,
  options?: { allowSame?: boolean },
): boolean;
export function transitionMarketplaceV1Lifecycle(
  from: MarketplaceV1LifecycleState | string,
  to: MarketplaceV1LifecycleState | string,
  options?: { allowSame?: boolean },
): MarketplaceV1LifecycleState;

declare const contracts: Readonly<{
  MARKETPLACE_V1_CONTRACT_VERSION: typeof MARKETPLACE_V1_CONTRACT_VERSION;
  MARKETPLACE_V1_MAX_UINT64: typeof MARKETPLACE_V1_MAX_UINT64;
  MARKETPLACE_V1_MAX_ATOMIC_VALUE: typeof MARKETPLACE_V1_MAX_ATOMIC_VALUE;
  MARKETPLACE_V1_SUPPORTED_NETWORKS: typeof MARKETPLACE_V1_SUPPORTED_NETWORKS;
  MARKETPLACE_V1_SORT_FIELDS: typeof MARKETPLACE_V1_SORT_FIELDS;
  MARKETPLACE_V1_PROTOCOL_IDS: typeof MARKETPLACE_V1_PROTOCOL_IDS;
  MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS: typeof MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS;
  MARKETPLACE_V1_DEFAULT_WALLET_EXECUTOR_BINDINGS: typeof MARKETPLACE_V1_DEFAULT_WALLET_EXECUTOR_BINDINGS;
  MARKETPLACE_V1_EXECUTION_KINDS: typeof MARKETPLACE_V1_EXECUTION_KINDS;
  MARKETPLACE_V1_SIGNER_KINDS: typeof MARKETPLACE_V1_SIGNER_KINDS;
  MARKETPLACE_V1_EXECUTION_CONTRACTS: typeof MARKETPLACE_V1_EXECUTION_CONTRACTS;
  MARKETPLACE_V1_EXECUTION_CONTRACT_BY_SCOPE: typeof MARKETPLACE_V1_EXECUTION_CONTRACT_BY_SCOPE;
  getMarketplaceV1ExecutionContract: typeof getMarketplaceV1ExecutionContract;
  MARKETPLACE_V1_EXECUTION_OWNERSHIP_KINDS: typeof MARKETPLACE_V1_EXECUTION_OWNERSHIP_KINDS;
  MARKETPLACE_V1_EXECUTION_OWNERSHIP_BY_PROTOCOL: typeof MARKETPLACE_V1_EXECUTION_OWNERSHIP_BY_PROTOCOL;
  getMarketplaceV1ExecutionOwnership: typeof getMarketplaceV1ExecutionOwnership;
  listMarketplaceV1ExecutionContracts: typeof listMarketplaceV1ExecutionContracts;
  MARKETPLACE_V1_LIFECYCLE_STATES: typeof MARKETPLACE_V1_LIFECYCLE_STATES;
  MARKETPLACE_V1_LIFECYCLE_TRANSITIONS: typeof MARKETPLACE_V1_LIFECYCLE_TRANSITIONS;
  normalizeMarketplaceV1ProtocolId: typeof normalizeMarketplaceV1ProtocolId;
  normalizeMarketplaceV1LifecycleState: typeof normalizeMarketplaceV1LifecycleState;
  normalizeMarketplaceV1Revision: typeof normalizeMarketplaceV1Revision;
  normalizeMarketplaceV1AtomicValue: typeof normalizeMarketplaceV1AtomicValue;
  normalizeMarketplaceV1Network: typeof normalizeMarketplaceV1Network;
  normalizeMarketplaceV1OpaqueId: typeof normalizeMarketplaceV1OpaqueId;
  normalizeMarketplaceV1Timestamp: typeof normalizeMarketplaceV1Timestamp;
  normalizeMarketplaceV1IdempotencyKey: typeof normalizeMarketplaceV1IdempotencyKey;
  normalizeMarketplaceV1WalletAuth: typeof normalizeMarketplaceV1WalletAuth;
  canTransitionMarketplaceV1Lifecycle: typeof canTransitionMarketplaceV1Lifecycle;
  transitionMarketplaceV1Lifecycle: typeof transitionMarketplaceV1Lifecycle;
}>;

export default contracts;

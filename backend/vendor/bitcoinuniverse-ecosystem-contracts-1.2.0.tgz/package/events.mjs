import contracts from './lib/events.js';

export const {
  ECOSYSTEM_EVENT_VERSION,
  ECOSYSTEM_EVENT_TYPES,
  EVENT_SCOPES,
  createEcosystemEvent,
  parseEcosystemEvent,
  eventInvalidates,
} = contracts;

export default contracts;

'use strict';

module.exports = require('./lib/utxo.js');

'use strict';

module.exports = require('./lib/marketplace.js');

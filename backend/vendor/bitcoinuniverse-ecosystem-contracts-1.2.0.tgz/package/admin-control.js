'use strict';

module.exports = Object.freeze({
  ...require('./lib/admin-control.js'),
  ...require('./lib/admin-control-payloads.js'),
  ...require('./lib/admin-control-security.js'),
});

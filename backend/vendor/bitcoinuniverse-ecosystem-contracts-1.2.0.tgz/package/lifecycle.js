'use strict';

module.exports = require('./lib/lifecycle.js');

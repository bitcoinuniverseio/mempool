import contracts from './lib/utxo.js';

export const {
  UTXO_CLASSIFICATIONS,
  UTXO_SELECTION_PURPOSES,
  DUST_LIMIT_SATS,
  normalizeOutpoint,
  classifyUtxo,
  assertSafeUtxoSelection,
  isSafeCardinalUtxo,
} = contracts;

export default contracts;

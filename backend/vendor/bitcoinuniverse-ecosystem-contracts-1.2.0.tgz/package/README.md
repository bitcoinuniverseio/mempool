# Universe ecosystem contracts

This package is the versioned interoperability boundary for Universe Main, Universe
Wallet, Universe Inscribe, and StampDEX. The applications remain independently
deployable, but they must consume the same package artifact.

## Network indexer health

`network-indexer-health-v1` is the shared producer/consumer contract for public
dependency health. Producers construct responses with
`createNetworkIndexerHealth`; consumers validate untrusted payloads with
`parseNetworkIndexerHealth`. Network identifiers are authoritative `chain:network`
values, timestamps are exact UTC ISO-8601 values, and each network reports
internally consistent chain tip, indexed height, lag, synchronization, freshness,
and contributing indexers. Unknown schema versions and legacy hyphenated network
keys fail closed.

## Authority

- Universe Wallet owns active wallet, account, role-specific addresses, network,
  permissions, UTXOs, transaction review, and signing.
- Universe Inscribe owns asset-creation configuration, transaction construction,
  broadcast tracking, indexing progress, and resumable creation workflows.
- StampDEX owns marketplace orders, PSBT construction, settlement, prices, and
  collection market statistics for protocols in its capability matrix.
- Universe Main owns the aggregated portfolio, discovery, search, activity,
  notifications, settings, and ecosystem navigation.
- Main's server-side event projection is the durable cross-application invalidation
  and reconciliation log. Wallet provider events are the live session authority.

## Contracts

The package exposes CommonJS, ESM, TypeScript declarations, and JSON Schema:

- wallet session and permissions;
- public ecosystem events and invalidation scopes;
- validated, versioned deep-link intents;
- protocol capability and marketplace-ownership matrix;
- authoritative transaction and creation lifecycle;
- fail-closed UTXO classification and selection;
- marketplace order validation;
- authoritative asset metadata and safe media URLs;
- a browser client for Wallet provider state, events, focus refresh, polling
  fallback, and same-origin tab synchronization.

All runtime parsers reject unknown fields where the boundary carries sensitive or
financial context. Public events and URLs reject private keys, seed material,
authentication values, PSBTs, raw transactions, signatures, extended public
keys, public keys, and wallet addresses. Wallet addresses are restored from the
permission-scoped Wallet provider instead of copied through public transports.

The `schemas/` directory contains the deployable v1 JSON Schemas for wallet
sessions, public events, deep-link intents, asset metadata, lifecycle snapshots,
classified UTXOs, marketplace orders, and trusted-resolver UTXO observation
shapes.

## Deep-link v1

The query envelope uses:

```text
uv=1
source=main|wallet|inscribe|stampdex
target=main|wallet|inscribe|stampdex
action=<validated action>
network=mainnet|testnet|signet|regtest
protocol=<authoritative protocol id>
asset=<public asset id>
collection=<public collection id>
listing=<public listing id>
offer=<public offer id>
tx=<public transaction id>
workflow=<opaque public workflow id>
tool=<tool id>
returnApp=<app id>
returnPath=<same-app path>
```

Account and address state is restored from Universe Wallet. It is intentionally not
serialized into a cross-origin URL. Pending private state remains keyed by the
public `workflow` identifier in its owning application.

Use `buildUniverseDeepLink()` to create links and `parseUniverseDeepLink()` at the
destination. Never read these query parameters directly.

## Lifecycle

The normal evidence order is:

```text
draft → configuring → validating → selecting-utxos → estimating-fees
→ simulating → ready-for-review → awaiting-approval → awaiting-signature
→ signed → submitted → broadcast → mempool → confirmed → indexing → indexed
→ protocol-recognized → wallet-visible → marketplace-pending → settled
→ tradable → completed
```

Applications can skip irrelevant intermediate states only through allowed forward
transitions or reconciliation evidence. A creation is not complete at `signed`,
`submitted`, `broadcast`, or `confirmed`. Marketplace work is complete only after
settlement evidence. Reorganizations and rollbacks move the state back into
reconciliation.

## UTXO safety

Unknown inventory is unsafe. A UTXO becomes a fee input only after an authoritative
inventory source verifies that it is cardinal, spendable, not reserved, not frozen,
not marketplace-locked, and confirmed unless the caller explicitly permits
unconfirmed inputs.

Asset transfers and marketplace actions must use the exact target outpoint.
Additional inputs must be verified cardinal fee inputs. A marketplace execution
cannot turn caller assertions such as `{ outpoint, spendable: true }`,
`inventoryVerified: true`, an owner ID, or a source label into authority.

Marketplace execution authorization is server-only. Construct
`createMarketplaceExecutionAuthorizer()` once in the backend composition root
with a fixed `appId` and a trusted `resolveAuthority` function. The public request
contains exactly `orderId` and `action`; the resolver must load the current order,
authenticated account ID, account network, and UTXO observation from backend
authorities:

```js
const marketplace = createMarketplaceExecutionAuthorizer({
  appId: 'stampdex',
  async resolveAuthority({ orderId, action, appId }) {
    return marketplaceRepository.resolveCurrentExecution({
      orderId,
      action,
      appId,
      authenticatedAccountId: requestIdentity.accountId,
    });
  },
});

const execution = await marketplace.authorize({
  orderId: request.params.orderId,
  action: request.body.action,
});
```

The authorizer binds the requested order ID and fixed application to that
backend resolution, verifies owner/account and network agreement, requires the
exact ordered outpoint and protocol inventory, and accepts only `live` or `fresh`
UTXO observations no more than 30 seconds old and no more than five seconds in
the future.

The trusted resolution is wrapped in a one-use, module-private `WeakSet`
attestation before validation. The attestation is never returned or serialized.
Direct `validateMarketplaceExecution()` calls, copied DTOs, schema-conforming
objects, and serialized execution results all fail with `AUTHORITY_REQUIRED`.
The `marketplace-resolver-utxo.v1.schema.json` file validates resolver output
shape only; matching it never grants authority. Missing, stale, degraded,
unknown, inconsistent, or non-authoritative resolution fails closed before
signing. Consume the returned execution result in the same backend operation;
never accept a result sent back by a browser as proof of authorization.

## Browser client

```js
import { createEcosystemClient } from '@bitcoinuniverse/ecosystem-contracts';

const ecosystem = createEcosystemClient({ appId: 'main' });
const unsubscribe = ecosystem.subscribe((message) => {
  if (message.kind === 'session') updateWalletUi(message.session);
  if (message.kind === 'event') invalidateQueries(message.event);
});

await ecosystem.start();
```

The client keeps session state in memory. It does not write wallet state,
addresses, tokens, or signing payloads to local storage. A protected
`getEcosystemState()` authorization failure, malformed response, or authoritative
disconnect replaces any retained connected session and emits a disconnected
session message. Legacy `getAccounts`/`getNetwork` reads are used only when the
protected method explicitly rejects with provider error `4200` or JSON-RPC
`-32601`; other failures never resurrect cached addresses.

## Compatibility and release

Breaking changes require a new schema version and package major version. Producers
must publish the old shape until all four consumers accept the new version. Every
repository records the artifact checksum used by its lockfile so CI can detect
contract drift.

Package 1.1.1 requires Node.js 24.19.0 and npm 11.17.0. Build and pack the
artifact only with those exact versions. Consumers must verify the package
manifest and archive SHA-256 before installation.

Run:

```text
npm test
npm run check
```

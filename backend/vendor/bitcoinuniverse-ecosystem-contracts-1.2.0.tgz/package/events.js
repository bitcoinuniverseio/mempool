'use strict';

module.exports = require('./lib/events.js');

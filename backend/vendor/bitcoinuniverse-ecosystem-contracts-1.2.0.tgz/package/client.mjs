import contracts from './lib/client.js';

export const {
  PROVIDER_ALIASES,
  PROVIDER_EVENT_NAME,
  CHANNEL_NAME,
  detectUniverseProvider,
  createEcosystemClient,
} = contracts;

export default contracts;

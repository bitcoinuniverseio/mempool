import contracts from './lib/lifecycle.js';

export const {
  LIFECYCLE_STATES,
  ACTIVE_LIFECYCLE_STATES,
  FAILURE_LIFECYCLE_STATES,
  TERMINAL_LIFECYCLE_STATES,
  LIFECYCLE_WORKFLOWS,
  LIFECYCLE_TRANSITIONS,
  LEGACY_STATUS_ALIASES,
  normalizeLifecycleState,
  normalizeLifecycleWorkflow,
  canTransitionLifecycle,
  transitionLifecycle,
  lifecycleRank,
  isTerminalLifecycleState,
  isFailureLifecycleState,
  isLifecycleComplete,
  reconcileLifecycle,
  createLifecycleSnapshot,
  freshnessFromTimestamps,
} = contracts;

export default contracts;

import contracts from './lib/health.js';

export const {
  NETWORK_INDEXER_HEALTH_SCHEMA_VERSION,
  canonicalNetworkIndexerHealthNetwork,
  createNetworkIndexerHealth,
  parseNetworkIndexerHealth
} = contracts;

export default contracts;

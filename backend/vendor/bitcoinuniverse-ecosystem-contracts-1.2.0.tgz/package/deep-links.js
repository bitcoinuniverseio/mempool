'use strict';

module.exports = require('./lib/deep-links.js');

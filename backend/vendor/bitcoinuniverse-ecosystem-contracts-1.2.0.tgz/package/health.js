'use strict';

module.exports = require('./lib/health.js');

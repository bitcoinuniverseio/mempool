'use strict';

module.exports = require('./lib/marketplace-v1.js');

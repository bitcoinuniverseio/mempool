import contracts from './lib/metadata.js';

export const {
  ASSET_KINDS,
  METADATA_FRESHNESS,
  METADATA_VERIFICATION,
  canonicalAssetId,
  normalizeAssetMetadata,
  normalizeSafeMediaUrl,
} = contracts;

export default contracts;

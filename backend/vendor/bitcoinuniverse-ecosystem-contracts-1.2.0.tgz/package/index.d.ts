export type EcosystemAppId = 'main' | 'wallet' | 'inscribe' | 'stampdex';
export type BitcoinNetwork = 'mainnet' | 'testnet' | 'signet' | 'regtest';
export type Freshness =
  | 'live'
  | 'fresh'
  | 'aging'
  | 'stale'
  | 'unknown'
  | 'degraded';
export type AddressRole = 'payment' | 'ordinals';
export type WalletPermission =
  | 'read-accounts'
  | 'read-addresses'
  | 'read-balances'
  | 'read-assets'
  | 'read-network'
  | 'request-signature'
  | 'request-transaction'
  | 'publish-invalidation';

export interface WalletAccount {
  id: string;
  label?: string;
  paymentAddress?: string;
  ordinalsAddress?: string;
  addressMode: 'separate' | 'shared' | 'payment-only' | 'ordinals-only';
}

export interface WalletSession {
  version: 1;
  wallet: { id: string; name: string; provider: string };
  connected: boolean;
  locked: boolean;
  account: WalletAccount | null;
  network: BitcoinNetwork;
  permissions: WalletPermission[];
  connectedApp?: {
    appId: EcosystemAppId;
    origin: string;
    permissions: WalletPermission[];
  };
  revision: number;
  updatedAt: string;
  freshness: Freshness;
  warnings: string[];
}

export interface DeepLinkIntent {
  version?: 1;
  sourceApp: EcosystemAppId;
  targetApp: EcosystemAppId;
  action: string;
  network: BitcoinNetwork;
  protocol?: string;
  assetId?: string;
  collectionId?: string;
  listingId?: string;
  offerId?: string;
  transactionId?: string;
  workflowId?: string;
  toolId?: string;
  returnApp?: EcosystemAppId;
  returnPath?: string;
}

export interface EcosystemEvent {
  version: 1;
  id: string;
  type: string;
  sourceApp: EcosystemAppId;
  network: BitcoinNetwork;
  scope: string;
  subject?: { kind: string; id: string; protocol?: string };
  correlationId?: string;
  idempotencyKey?: string;
  revision: number;
  occurredAt: string;
  observedAt: string;
  freshness: Freshness;
  data?: Record<
    string,
    string | number | boolean | null | Array<string | number | boolean>
  >;
}

export type LifecycleState =
  | 'draft'
  | 'configuring'
  | 'validating'
  | 'selecting-utxos'
  | 'estimating-fees'
  | 'simulating'
  | 'ready-for-review'
  | 'awaiting-approval'
  | 'awaiting-signature'
  | 'signed'
  | 'submitted'
  | 'broadcast'
  | 'mempool'
  | 'confirmed'
  | 'indexing'
  | 'indexed'
  | 'protocol-recognized'
  | 'wallet-visible'
  | 'marketplace-pending'
  | 'settled'
  | 'tradable'
  | 'completed'
  | 'rejected'
  | 'failed'
  | 'expired'
  | 'cancelled'
  | 'dropped'
  | 'replaced'
  | 'reorged'
  | 'conflicted'
  | 'rollback';
export type LifecycleWorkflow =
  | 'transaction'
  | 'creation'
  | 'marketplace'
  | 'transfer';

export interface LifecycleSnapshot {
  state: LifecycleState;
  workflow: LifecycleWorkflow;
  revision: number;
  observedAt: string;
  complete: boolean;
  terminal: boolean;
  failure: boolean;
  reason?: string;
}

export interface ClassifiedUtxo {
  version: 1;
  outpoint: string;
  valueSats: number;
  confirmations: number;
  confirmed: boolean;
  spendable: boolean;
  safeForFees: boolean;
  classifications: string[];
  protocols: string[];
  reasons: string[];
}

export interface MarketplaceOrderBase {
  version: 1;
  id: string;
  state: string;
  protocol: string;
  network: BitcoinNetwork;
  assetId: string;
  collectionId?: string;
  priceSats: number;
  quantity: number;
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  revision: number;
  idempotencyKey: string;
  sourceApp: EcosystemAppId;
}

export interface MarketplaceAssetOrder extends MarketplaceOrderBase {
  kind: 'listing' | 'sale' | 'auction';
  outpoint: string;
  ownerAccountId: string;
  makerAccountId?: string;
}

export interface MarketplaceOfferOrder extends MarketplaceOrderBase {
  kind: 'offer';
  makerAccountId: string;
  ownerAccountId?: string;
  outpoint?: string;
}

export type MarketplaceOrder = MarketplaceAssetOrder | MarketplaceOfferOrder;

export type MarketplaceUtxoFreshness = 'live' | 'fresh';

export interface MarketplaceUtxoObservation extends ClassifiedUtxo {
  observedAt: string;
  freshness: MarketplaceUtxoFreshness;
}

export type MarketplaceAction =
  | 'list'
  | 'update-listing'
  | 'unlist'
  | 'buy'
  | 'make-offer'
  | 'accept-offer'
  | 'cancel-offer'
  | 'sell';

export interface MarketplaceExecutionRequest {
  orderId: string;
  action: MarketplaceAction;
}

export interface MarketplaceAuthorityQuery extends MarketplaceExecutionRequest {
  appId: EcosystemAppId;
}

export interface MarketplaceAuthorityResolution {
  order: MarketplaceOrder | Record<string, unknown>;
  accountId: string;
  network: BitcoinNetwork;
  utxo?: MarketplaceUtxoObservation;
}

export type MarketplaceAuthorityResolver = (
  query: Readonly<MarketplaceAuthorityQuery>,
) => MarketplaceAuthorityResolution | Promise<MarketplaceAuthorityResolution>;

export interface MarketplaceExecutionResult {
  orderId: string;
  order: MarketplaceOrder;
  action: MarketplaceAction;
  appId: EcosystemAppId;
  accountId: string;
  network: BitcoinNetwork;
  authorizedAt: string;
  utxo?: MarketplaceUtxoObservation;
  valid: true;
}

export interface MarketplaceExecutionAuthorizer {
  readonly appId: EcosystemAppId;
  authorize(
    request: MarketplaceExecutionRequest,
  ): Promise<Readonly<MarketplaceExecutionResult>>;
}

export interface AssetMetadata {
  version: 1;
  canonicalId: string;
  network: BitcoinNetwork;
  protocol: string;
  assetId: string;
  kind: string;
  name: string;
  symbol?: string;
  description?: string;
  collectionId?: string;
  contentType?: string;
  imageUrl?: string;
  contentUrl?: string;
  thumbnailUrl?: string;
  freshness: Freshness;
  verification: string;
  observedAt: string;
  safety?: { contentSafe: boolean; activeContent: boolean; reason?: string };
}

export interface EcosystemClientMessage {
  kind: 'session' | 'event';
  reason?: string;
  session?: WalletSession;
  event?: EcosystemEvent;
  local?: boolean;
}

export interface EcosystemClient {
  readonly appId: EcosystemAppId;
  readonly origin?: string;
  start(): Promise<WalletSession>;
  stop(): void;
  refresh(reason?: string): Promise<WalletSession>;
  publish(
    event: Omit<Partial<EcosystemEvent>, 'version' | 'id'> &
      Pick<EcosystemEvent, 'type' | 'scope'>,
  ): Promise<EcosystemEvent>;
  subscribe(listener: (message: EcosystemClientMessage) => void): () => void;
  getProvider(): unknown;
  getSession(): WalletSession;
  isStarted(): boolean;
}

export class ContractValidationError extends Error {
  code: string;
  path: string;
}

export const CONTRACT_VERSION: '1.0.0';
export const SCHEMA_VERSION: 1;
export const NETWORK_INDEXER_HEALTH_SCHEMA_VERSION: 'network-indexer-health-v1';
export interface NetworkIndexerHealthState {
  chainTip: number;
  indexedHeight: number;
  lag: number;
  ready: boolean;
  synchronized: boolean;
  lastSuccessfulUpdate: string | null;
  indexers: string[];
  [key: string]: unknown;
}
export interface NetworkIndexerHealth {
  schemaVersion: 'network-indexer-health-v1';
  ok: boolean;
  timestamp: string;
  networks: Record<string, NetworkIndexerHealthState>;
  indexers: object[];
  [key: string]: unknown;
}
export function canonicalNetworkIndexerHealthNetwork(
  value: string | null,
): string | null;
export function createNetworkIndexerHealth(
  input: Omit<NetworkIndexerHealth, 'schemaVersion'>,
): Readonly<NetworkIndexerHealth>;
export function parseNetworkIndexerHealth(
  input: unknown,
): Readonly<NetworkIndexerHealth>;
export const ECOSYSTEM_APP_IDS: readonly EcosystemAppId[];
export const BITCOIN_NETWORKS: readonly BitcoinNetwork[];
export const APPLICATION_RESPONSIBILITIES: Readonly<
  Record<EcosystemAppId, readonly string[]>
>;
export const APP_DEFINITIONS: Readonly<
  Record<EcosystemAppId, Readonly<Record<string, unknown>>>
>;
export const DEFAULT_APP_ORIGINS: Readonly<
  Record<EcosystemAppId, readonly string[]>
>;
export const FORBIDDEN_FIELD_PATTERN: RegExp;
export function fail(code: string, message: string, path?: string): never;
export function isPlainObject(value: unknown): value is Record<string, unknown>;
export function assertPlainObject<T extends object>(value: T, path?: string): T;
export function assertOnlyKeys(
  value: object,
  allowedKeys: Iterable<string>,
  path?: string,
): void;
export function normalizeString(
  value: unknown,
  options?: Record<string, unknown>,
): string;
export function normalizeOptionalString(
  value: unknown,
  options?: Record<string, unknown>,
): string | undefined;
export function normalizeEnum<T>(
  value: T,
  values: readonly T[],
  path?: string,
): T;
export function normalizeInteger(
  value: unknown,
  options?: Record<string, unknown>,
): number;
export function normalizeNumber(
  value: unknown,
  options?: Record<string, unknown>,
): number;
export function normalizeIsoDate(value: unknown, path?: string): string;
export function normalizeAppId(value: unknown, path?: string): EcosystemAppId;
export function normalizeNetwork(value: unknown, path?: string): BitcoinNetwork;
export function looksSensitive(value: unknown): boolean;
export function looksLikeWalletAddress(value: unknown): boolean;
export function safeUrlOrigin(
  value: string,
  options?: { allowLoopbackHttp?: boolean },
): string | null;
export function resolveAppIdForOrigin(
  origin: string,
  configuredOrigins?: Record<string, string[]>,
): EcosystemAppId | null;
export function resolveAppUrl(
  appId: EcosystemAppId,
  options?: { urls?: Partial<Record<EcosystemAppId, string>>; local?: boolean },
): string;
export function deepFreeze<T>(value: T): Readonly<T>;
export function frozenCopy<T>(value: T): Readonly<T>;

export interface ProtocolMarketplaceActionCapability {
  supported: boolean;
  mode?: string;
  reason?: string;
}

export interface ProtocolMarketplacePolicy {
  owner: EcosystemAppId;
  availability: string;
  featureGate: string | null;
  mode: string;
  capabilities: Readonly<Record<string, ProtocolMarketplaceActionCapability>>;
  sourceOfTruth: Readonly<{
    orderBook: string;
    ownership: string;
    settlement: string;
    protocolState: string;
  }>;
  authority: Readonly<{
    orders: string;
    ownership: string;
    settlement: string;
  }>;
  indexer: Readonly<{
    primary: string;
    fallbacks: readonly string[];
    mutationGate: string;
  }>;
  freshness: Readonly<{
    enforced: boolean;
    maxLagBlocks: number | null;
    maxObservationAgeMs: number | null;
    policy: string;
  }>;
  confirmation: Readonly<{
    listingMinConfirmations: number | null;
    settlementMinConfirmations: number | null;
    policy: string;
  }>;
  reorg: Readonly<{
    automaticReconciliation: boolean;
    policy: string;
  }>;
}

export interface ProtocolCapability {
  displayName: string;
  aliases: readonly string[];
  ownershipModel: string;
  chain: string;
  decimals: string;
  addressRoles: readonly string[];
  marketplace: EcosystemAppId | null;
  actions: Readonly<Partial<Record<EcosystemAppId, readonly string[]>>>;
  marketplacePolicy: ProtocolMarketplacePolicy | null;
}

export const PROTOCOL_CAPABILITIES: Readonly<
  Record<string, ProtocolCapability>
>;
export const PROTOCOL_ALIASES: Readonly<Record<string, string>>;
export const MARKETPLACE_CAPABILITY_ACTIONS: readonly string[];
export const MARKETPLACE_PROTOCOL_REGISTRY: Readonly<
  Record<string, ProtocolMarketplacePolicy>
>;
export function normalizeProtocolId(value: unknown): string | null;
export function getProtocolCapability(
  value: unknown,
): Readonly<Record<string, unknown>>;
export function getProtocolActions(
  protocolId: string,
  appId: EcosystemAppId,
): string[];
export function isProtocolActionSupported(
  protocolId: string,
  appId: EcosystemAppId,
  action: string,
): boolean;
export function getProtocolMarketplacePolicy(
  protocolId: string,
): Readonly<ProtocolMarketplacePolicy> | null;
export function getProtocolMarketplaceActionCapability(
  protocolId: string,
  action: string,
): Readonly<ProtocolMarketplaceActionCapability>;
export function explainUnsupportedProtocolAction(
  protocolId: string,
  appId: EcosystemAppId,
  action: string,
): string | null;

export const DEEP_LINK_VERSION: 1;
export const DEEP_LINK_ACTIONS: readonly string[];
export function createDeepLinkIntent(
  input: DeepLinkIntent,
): Readonly<
  Required<
    Pick<
      DeepLinkIntent,
      'version' | 'sourceApp' | 'targetApp' | 'action' | 'network'
    >
  > &
    Partial<DeepLinkIntent>
>;
export function buildUniverseDeepLink(input: {
  intent: DeepLinkIntent;
  baseUrl?: string;
  appUrls?: Partial<Record<EcosystemAppId, string>>;
  allowedOrigins?: Iterable<string>;
  local?: boolean;
}): string;
export function parseUniverseDeepLink(
  input: string,
  options?: {
    expectedTargetApp?: EcosystemAppId;
    allowedOrigins?: Iterable<string>;
    requireIntent?: boolean;
  },
): Readonly<DeepLinkIntent> | null;
export function containsSensitiveDeepLinkData(input: unknown): boolean;

export const WALLET_SESSION_VERSION: 1;
export const WALLET_PERMISSION_SCOPES: readonly WalletPermission[];
export const ADDRESS_ROLES: readonly AddressRole[];
export function normalizeBitcoinAddress(value: unknown, path?: string): string;
export function normalizeWalletSession(
  input: WalletSession,
): Readonly<WalletSession>;
export function walletSessionFromProviderState(
  providerState: unknown,
  options?: Record<string, unknown>,
): Readonly<WalletSession>;
export function createDisconnectedWalletSession(
  options?: Record<string, unknown>,
): Readonly<WalletSession>;

export const ECOSYSTEM_EVENT_VERSION: 1;
export const ECOSYSTEM_EVENT_TYPES: readonly string[];
export const EVENT_SCOPES: readonly string[];
export function createEcosystemEvent(
  input: Omit<Partial<EcosystemEvent>, 'version' | 'id'> &
    Pick<EcosystemEvent, 'type' | 'sourceApp' | 'network' | 'scope'>,
): Readonly<EcosystemEvent>;
export function parseEcosystemEvent(input: unknown): Readonly<EcosystemEvent>;
export function eventInvalidates(event: EcosystemEvent): string[];

export const LIFECYCLE_STATES: readonly LifecycleState[];
export const ACTIVE_LIFECYCLE_STATES: readonly LifecycleState[];
export const FAILURE_LIFECYCLE_STATES: readonly LifecycleState[];
export const TERMINAL_LIFECYCLE_STATES: readonly LifecycleState[];
export const LIFECYCLE_WORKFLOWS: readonly LifecycleWorkflow[];
export const LIFECYCLE_TRANSITIONS: Readonly<
  Record<LifecycleState, readonly LifecycleState[]>
>;
export const LEGACY_STATUS_ALIASES: Readonly<Record<string, LifecycleState>>;
export function normalizeLifecycleState(
  value: unknown,
  path?: string,
): LifecycleState;
export function normalizeLifecycleWorkflow(
  value: unknown,
  path?: string,
): LifecycleWorkflow;
export function canTransitionLifecycle(
  from: LifecycleState,
  to: LifecycleState,
  options?: { allowSame?: boolean; reconciliation?: boolean },
): boolean;
export function transitionLifecycle(
  from: LifecycleState,
  to: LifecycleState,
  options?: { allowSame?: boolean; reconciliation?: boolean },
): LifecycleState;
export function lifecycleRank(value: LifecycleState): number;
export function isTerminalLifecycleState(value: LifecycleState): boolean;
export function isFailureLifecycleState(value: LifecycleState): boolean;
export function isLifecycleComplete(
  value: LifecycleState,
  workflow?: LifecycleWorkflow,
): boolean;
export function reconcileLifecycle(
  current: LifecycleState,
  observation?: Record<string, boolean>,
): LifecycleState;
export function createLifecycleSnapshot(input?: {
  state?: string;
  workflow?: string;
  observedAt?: string;
  revision?: number;
  reason?: string;
}): Readonly<LifecycleSnapshot>;
export function freshnessFromTimestamps(
  input?: Record<string, unknown>,
): Freshness;

export const UTXO_CLASSIFICATIONS: readonly string[];
export const UTXO_SELECTION_PURPOSES: readonly string[];
export const DUST_LIMIT_SATS: 546;
export function normalizeOutpoint(input: unknown, path?: string): string;
export function classifyUtxo(
  input: Record<string, unknown>,
  options?: Record<string, unknown>,
): Readonly<ClassifiedUtxo>;
export function assertSafeUtxoSelection(
  input: Record<string, unknown>,
): Readonly<{
  purpose: string;
  targetOutpoints: string[];
  totalSats: number;
  utxos: ClassifiedUtxo[];
}>;
export function isSafeCardinalUtxo(
  input: Record<string, unknown>,
  options?: Record<string, unknown>,
): boolean;

export const MARKETPLACE_ORDER_STATES: readonly string[];
export const MARKETPLACE_ACTIONS: readonly MarketplaceAction[];
export const MARKETPLACE_UTXO_MAX_AGE_MS: 30000;
export const MARKETPLACE_UTXO_MAX_FUTURE_SKEW_MS: 5000;
export function normalizeMarketplaceOrder(
  input: Record<string, unknown>,
): Readonly<MarketplaceOrder>;
export function createMarketplaceExecutionAuthorizer(options: {
  appId: EcosystemAppId;
  resolveAuthority: MarketplaceAuthorityResolver;
}): MarketplaceExecutionAuthorizer;
/** Direct calls cannot supply the module-private authority attestation and always throw AUTHORITY_REQUIRED. */
export function validateMarketplaceExecution(attestation?: unknown): never;
export function marketplaceOwner(protocolId: string): EcosystemAppId;
export function marketplaceIdempotencyKey(input: {
  action: string;
  orderId: string;
  revision?: number;
}): string;

export const MARKETPLACE_V1_CONTRACT_VERSION: '1';
export const MARKETPLACE_V1_MAX_UINT64: '18446744073709551615';
export const MARKETPLACE_V1_MAX_ATOMIC_VALUE: '99999999999999999999999999999999999999999999999999999999999999999';
export const MARKETPLACE_V1_SUPPORTED_NETWORKS: readonly [
  'bitcoin:mainnet',
  'bitcoin:testnet',
  'bitcoin:signet',
  'bitcoin:regtest',
  'dogecoin:mainnet',
  'dogecoin:testnet',
  'fractal:mainnet',
  'fractal:testnet',
];
export type MarketplaceV1Network =
  (typeof MARKETPLACE_V1_SUPPORTED_NETWORKS)[number];
export const MARKETPLACE_V1_SORT_FIELDS: readonly [
  'createdAt',
  'updatedAt',
  'priceAtomic',
  'quantityAtomic',
  'expiresAt',
];
export const MARKETPLACE_V1_PROTOCOL_IDS: readonly [
  'ordinals',
  'tap',
  'dmt',
  'unat',
  'bitmap',
  'names',
  'dust20',
  'stamps',
  'src20',
  'brc20',
  'runes',
  'runes_native',
  'mezcal',
  'alkanes',
  'op_return',
  'op_names',
  'op_inscriptions',
  'op_drop',
  'drops',
  'tap_doge',
  'drc20',
  'doginals',
  'arc20',
  'atomicals_nft',
  'realms',
  'subrealms',
  'rare_sats',
  'cat20',
  'ordex',
];
export type MarketplaceV1ProtocolId =
  (typeof MARKETPLACE_V1_PROTOCOL_IDS)[number];
export const MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS: readonly [
  'list',
  'update-listing',
  'unlist',
  'buy',
  'make-offer',
  'accept-offer',
];
export type MarketplaceV1WalletExecutorAction =
  (typeof MARKETPLACE_V1_WALLET_EXECUTOR_ACTIONS)[number];
export const MARKETPLACE_V1_ATOMICALS_WALLET_PROTOCOL_IDS: readonly [
  'arc20',
  'atomicals_nft',
  'realms',
  'subrealms',
];
export interface MarketplaceV1WalletExecutorBinding {
  readonly walletExecutorId:
    | 'core-bitcoin-wallet-v1'
    | 'core-dogecoin-wallet-v1';
  readonly network: 'bitcoin:mainnet' | 'dogecoin:mainnet';
  readonly actions: readonly MarketplaceV1WalletExecutorAction[];
}
export const MARKETPLACE_V1_DEFAULT_WALLET_EXECUTOR_BINDINGS: Readonly<
  Partial<Record<MarketplaceV1ProtocolId, MarketplaceV1WalletExecutorBinding>>
>;
export type MarketplaceV1ExecutionKind =
  | 'core-wallet'
  | 'external-wallet'
  | 'external-marketplace'
  | 'external-psbt'
  | 'nostr-signature'
  | 'server-authorized'
  | 'read-only';
export type MarketplaceV1SignerKind =
  | 'bitcoin-wallet'
  | 'dogecoin-wallet'
  | 'external-wallet'
  | 'nostr-or-wallet-psbt'
  | 'server-identity'
  | 'none';
export type MarketplaceV1ExecutionAction =
  | 'view'
  | 'view-collection'
  | 'view-activity'
  | 'list'
  | 'update-listing'
  | 'unlist'
  | 'buy'
  | 'make-offer'
  | 'accept-offer'
  | 'cancel-offer'
  | 'sell'
  | 'settle'
  | 'reconcile';
export type MarketplaceV1AuthorityPort =
  | 'browse'
  | 'listing'
  | 'update'
  | 'delist'
  | 'purchase'
  | 'offers'
  | 'settlement';
export const MARKETPLACE_V1_AUTHORITY_PORT_BY_ACTION: Readonly<
  Record<MarketplaceV1ExecutionAction, MarketplaceV1AuthorityPort>
>;
export const MARKETPLACE_V1_PROTOCOL_NETWORKS: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1Network>
>;
export interface MarketplaceV1ExecutionContract {
  readonly protocolId: MarketplaceV1ProtocolId;
  readonly action: MarketplaceV1ExecutionAction;
  readonly advertised: boolean;
  readonly supportsMutation: boolean;
  readonly executionKind: MarketplaceV1ExecutionKind;
  readonly signerKind: MarketplaceV1SignerKind;
  readonly authorityOwner: string;
  readonly builderOwner: string;
  readonly validatorOwner: string;
  readonly broadcastOwner: string;
  readonly settlementOwner: string;
  readonly escrowModel: string;
  readonly custodyModel: string;
  readonly ownershipModel: string;
  readonly transferabilityProof: string;
  readonly network: MarketplaceV1Network;
  readonly requiredAuthority: string;
  readonly requiredDeploymentIdentity: string;
  readonly requiredEvidenceKind: string;
  readonly requiresBroadcast: boolean;
  readonly requiresSettlement: boolean;
  readonly walletExecutorId: string | null;
}
export const MARKETPLACE_V1_EXECUTION_KINDS: readonly MarketplaceV1ExecutionKind[];
export const MARKETPLACE_V1_SIGNER_KINDS: readonly MarketplaceV1SignerKind[];
export const MARKETPLACE_V1_EXECUTION_CONTRACTS: readonly MarketplaceV1ExecutionContract[];
export const MARKETPLACE_V1_EXECUTION_CONTRACT_BY_SCOPE: Readonly<
  Record<string, MarketplaceV1ExecutionContract>
>;
export interface MarketplaceV1AuthorityMatrixRow {
  readonly protocolId: MarketplaceV1ProtocolId;
  readonly network: MarketplaceV1Network;
  readonly availability: string;
  readonly featureGate: string | null;
  readonly staticCapabilities: Readonly<Record<string, unknown>>;
  readonly advertisedActions: readonly MarketplaceV1ExecutionAction[];
  readonly mutationActions: readonly MarketplaceV1ExecutionAction[];
  readonly requiredPorts: readonly MarketplaceV1AuthorityPort[];
  readonly executionKinds: readonly MarketplaceV1ExecutionKind[];
  readonly signerKinds: readonly MarketplaceV1SignerKind[];
  readonly requiredAuthorities: readonly string[];
  readonly requiredDeploymentIdentities: readonly string[];
  readonly requiredEvidenceKinds: readonly string[];
  readonly owners: Readonly<{
    authority: readonly string[];
    builder: readonly string[];
    validator: readonly string[];
    broadcast: readonly string[];
    settlement: readonly string[];
  }>;
  readonly walletExecutorBinding: MarketplaceV1WalletExecutorBinding | null;
}
export const MARKETPLACE_V1_AUTHORITY_MATRIX: readonly MarketplaceV1AuthorityMatrixRow[];
export const MARKETPLACE_V1_AUTHORITY_MATRIX_BY_PROTOCOL: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1AuthorityMatrixRow>
>;
export type MarketplaceV1ExecutionOwnership =
  | 'remote-authority'
  | 'core-native'
  | 'external-provider'
  | 'none';
export const MARKETPLACE_V1_EXECUTION_OWNERSHIP_KINDS: readonly MarketplaceV1ExecutionOwnership[];
export const MARKETPLACE_V1_EXECUTION_OWNERSHIP_BY_PROTOCOL: Readonly<
  Record<MarketplaceV1ProtocolId, MarketplaceV1ExecutionOwnership>
>;
export function getMarketplaceV1ExecutionOwnership(
  protocolId: unknown,
): MarketplaceV1ExecutionOwnership;
export function getMarketplaceV1ExecutionContract(
  protocolId: unknown,
  action: unknown,
): MarketplaceV1ExecutionContract;
export function listMarketplaceV1ExecutionContracts(options?: {
  advertisedOnly?: boolean;
  mutationOnly?: boolean;
}): MarketplaceV1ExecutionContract[];
export type MarketplaceV1LifecycleState =
  | 'draft'
  | 'prepared'
  | 'signed'
  | 'open'
  | 'reserved'
  | 'settling'
  | 'broadcast'
  | 'confirmed'
  | 'indexing'
  | 'indexed'
  | 'settled'
  | 'cancelling'
  | 'cancelled'
  | 'expired'
  | 'failed-retryable'
  | 'failed-final'
  | 'dropped'
  | 'replaced'
  | 'conflicted'
  | 'reorged'
  | 'recovering';
export const MARKETPLACE_V1_LIFECYCLE_STATES: readonly MarketplaceV1LifecycleState[];
export const MARKETPLACE_V1_LIFECYCLE_TRANSITIONS: Readonly<
  Record<MarketplaceV1LifecycleState, readonly MarketplaceV1LifecycleState[]>
>;
export function normalizeMarketplaceV1ProtocolId(
  value: unknown,
  path?: string,
): MarketplaceV1ProtocolId;
export function normalizeMarketplaceV1LifecycleState(
  value: unknown,
  path?: string,
): MarketplaceV1LifecycleState;
export function normalizeMarketplaceV1Revision(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1AtomicValue(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1Network(
  value: unknown,
  path?: string,
): MarketplaceV1Network;
export function normalizeMarketplaceV1OpaqueId(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1Timestamp(
  value: unknown,
  path?: string,
): string;
export function normalizeMarketplaceV1IdempotencyKey(
  value: unknown,
  path?: string,
): string;
export interface MarketplaceV1WalletAuth {
  readonly address: string;
  readonly nonce: string;
  readonly signature: string;
  readonly signatureType: 'bip322-simple' | 'dogecoin-signmessage';
}
export function normalizeMarketplaceV1WalletAuth(
  value: unknown,
  path?: string,
): Readonly<MarketplaceV1WalletAuth>;
export function canTransitionMarketplaceV1Lifecycle(
  from: MarketplaceV1LifecycleState | string,
  to: MarketplaceV1LifecycleState | string,
  options?: { allowSame?: boolean },
): boolean;
export function transitionMarketplaceV1Lifecycle(
  from: MarketplaceV1LifecycleState | string,
  to: MarketplaceV1LifecycleState | string,
  options?: { allowSame?: boolean },
): MarketplaceV1LifecycleState;

/** Atomic amounts are authoritative unsigned base-10 integer strings. */
export type MarketplaceV1AtomicValue = string;
export type MarketplaceV1OrderKind = 'listing' | 'offer';
export interface MarketplaceV1Order {
  version: '1';
  id: string;
  kind: MarketplaceV1OrderKind;
  protocolId: MarketplaceV1ProtocolId;
  network: string;
  assetId: string;
  state: MarketplaceV1LifecycleState;
  priceAtomic: MarketplaceV1AtomicValue;
  quantityAtomic: MarketplaceV1AtomicValue;
  makerAccountId: string;
  ownerAccountId?: string;
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  revision: string;
  idempotencyKey: string;
}

export interface MarketplaceV1ActionIntent {
  version: '1';
  id: string;
  protocolId: MarketplaceV1ProtocolId;
  network: string;
  action: string;
  state: MarketplaceV1LifecycleState;
  orderId?: string;
  assetId?: string;
  priceAtomic?: MarketplaceV1AtomicValue;
  quantityAtomic?: MarketplaceV1AtomicValue;
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  revision: string;
  idempotencyKey: string;
}

export const ASSET_KINDS: readonly string[];
export const METADATA_FRESHNESS: readonly Freshness[];
export const METADATA_VERIFICATION: readonly string[];
export function canonicalAssetId(input: {
  network: BitcoinNetwork;
  protocol: string;
  assetId?: string;
  id?: string;
}): string;
export function normalizeAssetMetadata(
  input: Record<string, unknown>,
): Readonly<AssetMetadata>;
export function normalizeSafeMediaUrl(
  value: unknown,
  path?: string,
): string | undefined;

export const PROVIDER_ALIASES: readonly string[];
export const PROVIDER_EVENT_NAME: 'ecosystemChanged';
export const CHANNEL_NAME: 'bitcoinuniverse.ecosystem.v1';
export function detectUniverseProvider(
  windowLike?: Record<string, unknown>,
  aliases?: readonly string[],
): unknown;
export function createEcosystemClient(
  options?: Record<string, unknown>,
): EcosystemClient;

declare const contracts: Record<string, unknown>;
export default contracts;

import contracts from './lib/deep-links.js';

export const {
  DEEP_LINK_VERSION,
  DEEP_LINK_ACTIONS,
  createDeepLinkIntent,
  buildUniverseDeepLink,
  parseUniverseDeepLink,
  containsSensitiveDeepLinkData,
} = contracts;

export default contracts;
